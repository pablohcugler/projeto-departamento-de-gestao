import { describe, expect, it } from "vitest";
import { primeiroNome, saudacaoPorHora } from "./saudacao";

const as = (h: number, m = 0) => new Date(2026, 10, 14, h, m);

describe("saudação", () => {
  it("manhã, tarde e noite", () => {
    expect(saudacaoPorHora(as(5))).toBe("Bom dia");
    expect(saudacaoPorHora(as(11, 59))).toBe("Bom dia");
    expect(saudacaoPorHora(as(12))).toBe("Boa tarde");
    expect(saudacaoPorHora(as(17, 59))).toBe("Boa tarde");
    expect(saudacaoPorHora(as(18))).toBe("Boa noite");
    expect(saudacaoPorHora(as(0))).toBe("Boa noite");
    expect(saudacaoPorHora(as(4, 59))).toBe("Boa noite");
  });
  it("primeiro nome", () => {
    expect(primeiroNome("  pablo henrique rogerio ")).toBe("Pablo");
    expect(primeiroNome("MARIA")).toBe("Maria");
    expect(primeiroNome("")).toBe("");
    expect(primeiroNome(null)).toBe("");
  });
});
